#!/bin/sh 
lex tiny.l
yacc -d tiny.y
